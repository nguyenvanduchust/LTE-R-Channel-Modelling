Van Duc Nguyen, 2017, HUST
1. main program: channel_transfer_function_mainprogram.m
2. channel_profile.am: a file store the discrete channel profile coefficients
3. MCM_channel_model: a function creates the channel coefficient (CIR and CTF) according to the Monte Carlo Method
4. ChannelAutocorrelationFunction_Comparison.m: plot the time correlation function of the channel for different Doppler frequency
