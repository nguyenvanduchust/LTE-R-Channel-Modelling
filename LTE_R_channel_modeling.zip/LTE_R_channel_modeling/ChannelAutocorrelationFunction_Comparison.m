
load R_TimeCorrelation_fd_106Hz.mat;


plot(Deltat,real(R_time_corr),'bo-','MarkerSize',3);

hold on;

load R_TimeCorrelation_fd_194Hz.mat;


plot(Deltat,real(R_time_corr),'kx-','MarkerSize',3);



load R_TimeCorrelation_fd_324Hz.mat;


plot(Deltat,real(R_time_corr),'r*-','MarkerSize',3);
ylabel('Time correlation function of the channel R(\Delta t)');
xlabel('\Delta t in seconds');


legend('f_D_{max} = 106 Hz', 'f_D_{max} = 194 Hz', 'f_D_{max} = 324 Hz');
axis([-0.04 0.04 -0.7 1.1]);
hold off;