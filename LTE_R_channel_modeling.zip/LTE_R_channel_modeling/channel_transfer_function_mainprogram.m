clear all;
%=========================================================================
% LTE-R channel modelled by the Monte carlo method, released on 28th March
% 2016
%=========================================================================
% channel paramter setup
%===================================================================

NFFT = 1024;                    % FFT length of the LTE-R system!
G = 21;                         % guard interval length is selected depending on the channel

B = 10e+6;                      % total bandwidth of the LTE-R system is 10 MHz

t_a = 1/B;                      % sampling interval according to the Nyquist theory

Deltaf = B/NFFT;                % sub-carrier spacing


T_S = NFFT * t_a;               % OFDM symbol duration

number_of_summations = 40;      % Number of summations for Monte-Carlo method

f_dmax = 1204.0;                % Maximum Doppler frequency of the LTE-R channel is  selelected from 106 Hz, 194 Hz,  324 Hz, 500 Hz, 722 Hz, 833 Hz, 1024 Hz;

load channel_profile.am -ascii; % channel delay profile

rho = channel_profile(1:4);     % channel profile  channel 

N_P = length(rho);              % CIR length


u = rand(N_P,number_of_summations); % a random variable requested by the Monte-Carlo method

N = 500; % Observe the channel for N OFDM symbols

initial_time = 1000*rand(1);   % set an initial absolute time for simulation


h = []; % channel impulse response matrix
H = []; % channel transfer function matrix
H_t = []; % H(f0,t), prepared for calculation of the time-correlation function of the channel

for i = 1:N;
    h_i = MCM_channel_model(u, initial_time, number_of_summations, T_S, f_dmax, rho);
    % generation of the CIR coefficient

    h_i_tem = [h_i, zeros(1, NFFT -N_P)];

    H_i_tem = fft(h_i_tem);
    H_t = [H_t,H_i_tem(1)]; % The channel transfer function H(f0,t)
    % CTF coefficient
    
    H_i = [H_i_tem(NFFT/2+1 : NFFT), H_i_tem(1 : NFFT/2)];
    
    initial_time = initial_time +  T_S;
    % incseare the observed time

    h = [h; h_i];
    H = [H; H_i];
    
    
end;

x = (1:NFFT) * Deltaf; % prepare for the display in frequency domain
y = (1:N) * T_S; % prepare for the display in time domain

Deltat = -(N-1)*T_S:T_S:(N-1)*T_S;
R_time_corr = xcorr(H_t,'coeff');
% store the results for the purpose of comparison
save R_TimeCorrelation_fd_1204Hz.mat Deltat R_time_corr;
% plot the channel transfer function of the modelled channel

figure(1);
mesh(x,y,10*log10(abs(H)))
xlabel('f [Hz]')
ylabel('t [s]')
zlabel('10*log10(|H(f, t)|)')
title('Doppler frequency 1204 Hz')
% plot the time correlation function of the channel 

figure(2);
plot(Deltat,real(R_time_corr));
ylabel('Time correlation function of the channel R(\Delta t)');
xlabel('\Delta t in seconds');
legend('Doppler frequency f_D = 1204 Hz');